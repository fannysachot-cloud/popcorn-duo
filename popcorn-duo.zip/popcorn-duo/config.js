// Address of the invite page (the "site" folder, once it is online). Empty: invite links open Netflix directly.
self.POPCORN_DUO = {
  invitePage: "https://fannysachot-cloud.github.io/popcorn-duo/",
};
