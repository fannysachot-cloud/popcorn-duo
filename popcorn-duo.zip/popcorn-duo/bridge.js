// Runs on the invite page when Popcorn Duo is installed: go straight to Netflix, in the room.
// Invite page address: …/popcorn-duo/#ROOM.TOKEN.WATCH_ID
(() => {
  const match = location.hash.match(/^#([A-Za-z0-9]{6})\.([a-z0-9]{8,})\.(\d*)$/);
  if (!match) return;
  const [, code, token, watch] = match;
  location.replace("https://www.netflix.com/" + (watch ? "watch/" + watch : "browse") + "#popcornduo=" + code + "." + token);
})();
