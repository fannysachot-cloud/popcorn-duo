// Right after installation, an invite page left open in a tab is not reached by bridge.js
// (Chrome only injects content scripts into pages loaded afterwards): send that tab to Netflix ourselves.
chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  if (reason !== "install") return;
  const tabs = await chrome.tabs.query({ url: "https://*.github.io/popcorn-duo/*" });
  for (const tab of tabs) {
    const match = (tab.url || "").match(/#([A-Za-z0-9]{6})\.([a-z0-9]{8,})\.(\d*)$/);
    if (!match) continue;
    const [, code, token, watch] = match;
    const url = "https://www.netflix.com/" + (watch ? "watch/" + watch : "browse") + "#popcornduo=" + code + "." + token;
    await chrome.tabs.update(tab.id, { url, active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
    return;
  }
});
