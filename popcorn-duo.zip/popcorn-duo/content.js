// Popcorn Duo: syncs Netflix playback between two people and shows their webcams.
// Connection goes peer-to-peer (WebRTC); the free public PeerJS server only introduces the two browsers.
(() => {
  const PREFIX = "duowatch-";
  const STORE_KEY = "duowatch:session";
  const INVITE_KEY = "popcornduo:invite"; // set by invite.js from the link's #popcornduo=ROOM.TOKEN
  const INVITE_PAGE = (self.POPCORN_DUO && self.POPCORN_DUO.invitePage) || "";
  const SESSION_TTL = 3 * 60 * 60 * 1000; // auto-rejoin after a reload of the same tab for 3h (sessionStorage is per tab)
  const SIZES = [220, 320, 440];

  let peer = null;
  let conn = null;
  let call = null;
  let localStream = null;
  let isHost = false;
  let roomCode = null;
  let leaving = false;
  let ignoreLocalUntil = 0; // video events triggered by remote commands are not echoed back
  let lastLocalAction = 0;
  let heartbeat = null;
  let sizeIndex = 1;
  // Host: one-time invite tokens not used yet, and the pass given to the accepted guest for reconnects.
  // Guest: what we present to the host (an invite token the first time, then the pass).
  let invites = new Set();
  let guestPass = null;
  let credentials = null;
  let pendingGuest = null;

  const getVideo = () => document.querySelector("video");
  const watchId = () => (location.pathname.match(/\/watch\/(\d+)/) || [])[1] || null;
  const randomCode = () => Math.random().toString(36).slice(2, 8).toUpperCase();
  const randomToken = () =>
    Array.from(crypto.getRandomValues(new Uint8Array(12)), (b) => "abcdefghijkmnpqrstuvwxyz23456789"[b % 32]).join("");
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));

  function saveSession(data) {
    try {
      if (data) sessionStorage.setItem(STORE_KEY, JSON.stringify({ ...data, at: Date.now() }));
      else sessionStorage.removeItem(STORE_KEY);
    } catch (e) {}
  }

  function loadSession() {
    try {
      const s = JSON.parse(sessionStorage.getItem(STORE_KEY));
      return s && Date.now() - s.at < SESSION_TTL ? s : null;
    } catch (e) {
      return null;
    }
  }

  // ---------- UI ----------

  const host = document.createElement("div");
  host.style.cssText = "position:fixed;top:16px;right:16px;z-index:2147483647;";
  const root = host.attachShadow({ mode: "open" });
  root.innerHTML = `
    <style>
      * { box-sizing: border-box; font-family: -apple-system, system-ui, sans-serif; }
      .panel { width: 320px; background: rgba(20,20,20,.92); color: #fff; border-radius: 14px;
               box-shadow: 0 8px 30px rgba(0,0,0,.5); overflow: hidden; font-size: 13px; }
      .bar { display: flex; align-items: center; gap: 8px; padding: 8px 10px; cursor: move; user-select: none; }
      .title { font-weight: 700; color: #e50914; }
      .status { flex: 1; opacity: .75; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .body { padding: 0 10px 10px; }
      .min .body { display: none; }
      button { background: #333; color: #fff; border: 0; border-radius: 8px; padding: 7px 10px;
               cursor: pointer; font-size: 13px; }
      button:hover { background: #444; }
      button.primary { background: #e50914; }
      button.off { background: #7a1d1d; }
      .icon { padding: 2px 8px; background: transparent; }
      .row { display: flex; gap: 6px; margin-top: 8px; align-items: center; }
      .row > * { flex: 1; }
      input[type=text] { background: #222; color: #fff; border: 1px solid #444; border-radius: 8px;
                         padding: 7px 8px; font-size: 13px; text-transform: uppercase; min-width: 0; }
      .setup button.primary { width: 100%; }
      .vids { position: relative; background: #000; border-radius: 10px; overflow: hidden; aspect-ratio: 4/3; }
      .vids video { display: block; }
      .remote { width: 100%; height: 100%; object-fit: cover; }
      .self { position: absolute; right: 6px; bottom: 6px; width: 30%; border-radius: 6px;
              border: 2px solid rgba(255,255,255,.6); transform: scaleX(-1); }
      .hint { margin: 8px 0 0; opacity: .7; font-size: 12px; }
      .request { margin-bottom: 8px; padding: 10px; background: #12351f; border-radius: 8px; }
      .invite { width: 100%; margin-bottom: 8px; }
      input.invitelink { width: 100%; margin-bottom: 8px; text-transform: none; font-size: 11px; }
      .notice { margin-top: 8px; padding: 8px; background: #3a2a00; border-radius: 8px; }
      .notice button { margin-top: 6px; width: 100%; }
      label { display: flex; align-items: center; gap: 6px; opacity: .85; }
      label.check { cursor: pointer; font-size: 12px; }
      label.check input { accent-color: #e50914; margin: 0; }
      input[type=range] { flex: 1; accent-color: #e50914; }
      [hidden] { display: none !important; }
    </style>
    <div class="panel">
      <div class="bar">
        <span class="title">🍿 Popcorn Duo</span>
        <span class="status">Pas connecté·e</span>
        <button class="icon size" title="Taille">⤢</button>
        <button class="icon minbtn" title="Réduire">–</button>
      </div>
      <div class="body">
        <div class="setup">
          <button class="primary create">Créer une salle</button>
          <p class="hint info">Crée une salle, puis envoie le lien d'invitation à la personne de ton choix.</p>
        </div>
        <div class="room" hidden>
          <div class="request" hidden>
            Ton invité·e veut entrer dans la salle.
            <div class="row">
              <button class="primary accept">Accepter</button>
              <button class="refuse">Refuser</button>
            </div>
          </div>
          <div class="inviting">
            <button class="primary invite">Copier le lien d'invitation</button>
            <input type="text" class="invitelink" readonly hidden>
          </div>
          <div class="vids">
            <video class="remote" autoplay playsinline></video>
            <video class="self" autoplay playsinline muted></video>
          </div>
          <div class="notice" hidden>
            L'autre personne regarde un autre titre ou épisode.
            <button class="primary goto">Aller au même endroit</button>
          </div>
          <div class="row">
            <label>Voix <input type="range" class="vol" min="0" max="2" step="0.05" value="1.4"></label>
          </div>
          <div class="row">
            <label class="check"><input type="checkbox" class="duck" checked> Baisser le film quand l'autre parle</label>
          </div>
          <div class="row">
            <button class="mic">Micro</button>
            <button class="cam">Caméra</button>
            <button class="leave">Quitter</button>
          </div>
          <p class="hint inviting">Chaque lien ne marche qu'une fois, et tu valides chaque arrivée.</p>
        </div>
      </div>
    </div>`;

  const $ = (sel) => root.querySelector(sel);
  const panel = $(".panel");
  const remoteV = $(".remote");
  const selfV = $(".self");
  let pendingWatch = null;

  const setStatus = (text) => ($(".status").textContent = text);

  function showRoom(show) {
    $(".setup").hidden = show;
    $(".room").hidden = !show;
    root.querySelectorAll(".inviting").forEach((el) => (el.hidden = !isHost));
  }

  function showNotice(otherWatch) {
    pendingWatch = otherWatch;
    $(".notice").hidden = !otherWatch;
  }

  // Keep Netflix keyboard shortcuts (space, arrows…) from firing while typing in the panel.
  for (const type of ["keydown", "keyup", "keypress"]) {
    host.addEventListener(type, (e) => e.stopPropagation());
  }

  // Drag the panel by its title bar.
  $(".bar").addEventListener("pointerdown", (e) => {
    if (e.target.closest("button")) return;
    const rect = host.getBoundingClientRect();
    const dx = e.clientX - rect.left;
    const dy = e.clientY - rect.top;
    const move = (ev) => {
      host.style.left = Math.max(0, ev.clientX - dx) + "px";
      host.style.top = Math.max(0, ev.clientY - dy) + "px";
      host.style.right = "auto";
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  });

  $(".minbtn").onclick = () => panel.classList.toggle("min");
  $(".size").onclick = () => {
    sizeIndex = (sizeIndex + 1) % SIZES.length;
    panel.style.width = SIZES[sizeIndex] + "px";
  };
  $(".vol").oninput = () => {
    if (voiceGain) voiceGain.gain.value = Number($(".vol").value);
    routeVoice();
  };
  $(".duck").onchange = () => {
    if (!$(".duck").checked && ducking.active) setDucked(false);
  };
  $(".create").onclick = () => createRoom(randomCode());
  $(".leave").onclick = leave;
  $(".invite").onclick = copyInvite;
  $(".accept").onclick = () => answerRequest(true);
  $(".refuse").onclick = () => answerRequest(false);

  // Each link carries a fresh one-time token. It goes through the invite page, which gets
  // Popcorn Duo installed if needed, then lands on the same title and joins this room.
  function inviteLink() {
    const token = randomToken();
    invites.add(token);
    saveHostSession();
    const watch = watchId() || "";
    if (INVITE_PAGE) return INVITE_PAGE + "#" + roomCode + "." + token + "." + watch;
    const path = watch ? "/watch/" + watch : "/browse";
    return location.origin + path + "#popcornduo=" + roomCode + "." + token;
  }

  async function copyInvite() {
    const button = $(".invite");
    const link = inviteLink();
    try {
      await navigator.clipboard.writeText(link);
      button.textContent = "Lien copié ✓ Envoie-le !";
    } catch (e) {
      // Clipboard access can be refused: show the link so it can be copied by hand.
      const field = $(".invitelink");
      field.value = link;
      field.hidden = false;
      field.select();
      button.textContent = "Copie le lien ci-dessous";
    }
    setTimeout(() => (button.textContent = "Copier le lien d'invitation"), 4000);
  }
  $(".goto").onclick = () => {
    if (pendingWatch) location.href = "/watch/" + pendingWatch;
  };
  $(".mic").onclick = (e) => toggleTrack("audio", e.target);
  $(".cam").onclick = (e) => toggleTrack("video", e.target);

  function toggleTrack(kind, button) {
    if (!localStream) return;
    const tracks = kind === "audio" ? localStream.getAudioTracks() : localStream.getVideoTracks();
    tracks.forEach((t) => (t.enabled = !t.enabled));
    button.classList.toggle("off", tracks.length > 0 && !tracks[0].enabled);
  }

  // Netflix puts its player container in fullscreen: move the panel inside it to stay visible.
  document.addEventListener("fullscreenchange", () => {
    (document.fullscreenElement || document.body).appendChild(host);
  });

  document.body.appendChild(host);

  // ---------- Camera ----------

  async function getMedia() {
    if (localStream) return localStream;
    try {
      localStream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480 },
        audio: { echoCancellation: true, noiseSuppression: true },
      });
      selfV.srcObject = localStream;
    } catch (e) {
      setStatus("Caméra/micro refusés — synchro seule");
    }
    return localStream;
  }

  // ---------- Connection ----------

  function newPeer(id) {
    return new Promise((resolve, reject) => {
      const p = id ? new peerjs.Peer(id) : new peerjs.Peer();
      p.on("open", () => resolve(p));
      p.on("error", (err) => {
        if (!p.open) reject(err);
        else onPeerError(err);
      });
      p.on("disconnected", () => {
        if (!leaving && !p.destroyed) p.reconnect();
      });
    });
  }

  function onPeerError(err) {
    if (err.type === "peer-unavailable") {
      setStatus("Salle introuvable, nouvel essai…");
      if (!isHost) setTimeout(connectToHost, 4000);
    } else {
      setStatus("Erreur : " + err.type);
    }
  }

  function listenForCalls() {
    peer.on("call", (incoming) => {
      // Only video from the accepted guest (or, for a guest, from the host) is answered.
      const expected = isHost ? conn && conn.peer : PREFIX + roomCode;
      if (incoming.peer !== expected) return incoming.close();
      setupCall(incoming);
      incoming.answer(localStream || undefined);
    });
  }

  function saveHostSession() {
    saveSession({ role: "host", code: roomCode, invites: [...invites], pass: guestPass });
  }

  async function createRoom(code, restored = {}) {
    ensureAudio();
    isHost = true;
    invites = new Set(restored.invites || []);
    guestPass = restored.pass || null;
    roomCode = code;
    leaving = false;
    showRoom(true);
    setStatus("Ouverture de la salle…");
    await getMedia();
    // After a reload the public server may still hold our previous id for a few seconds.
    for (let attempt = 0; attempt < 8 && !peer; attempt++) {
      if (leaving || roomCode !== code) return; // "Quitter" was clicked while retrying
      try {
        const opened = await newPeer(PREFIX + code);
        if (leaving || roomCode !== code) return opened.destroy();
        peer = opened;
      } catch (err) {
        if (err.type !== "unavailable-id") {
          setStatus("Erreur : " + err.type);
          return;
        }
        setStatus("Réouverture de la salle…");
        await wait(3000);
      }
    }
    if (!peer) return setStatus("Code déjà pris — crée une autre salle");
    saveHostSession();
    setStatus("En attente de l'autre personne…");
    peer.on("connection", onIncoming);
    listenForCalls();
    heartbeat = setInterval(sendState, 5000);
  }

  // ---------- Who may enter (host side) ----------

  function onIncoming(c) {
    const meta = c.metadata || {};
    if (guestPass && meta.pass === guestPass) return acceptGuest(c);
    if (meta.token && invites.has(meta.token)) {
      invites.delete(meta.token); // one use only, whatever the host answers
      saveHostSession();
      return askHost(c);
    }
    refuse(c, "Ce lien a déjà servi ou n'est plus valable. Demande un nouveau lien.");
  }

  function askHost(c) {
    if (pendingGuest) refuse(pendingGuest, "La salle a reçu une autre demande.");
    pendingGuest = c;
    $(".request").hidden = false;
    panel.classList.remove("min");
    c.on("close", () => {
      if (pendingGuest === c) answerRequest(null);
    });
  }

  function answerRequest(accepted) {
    const c = pendingGuest;
    pendingGuest = null;
    $(".request").hidden = true;
    if (!c || accepted === null) return;
    if (accepted) {
      guestPass = randomToken();
      saveHostSession();
      acceptGuest(c);
    } else {
      refuse(c, "L'hôte n'a pas accepté la demande.");
    }
  }

  function acceptGuest(c) {
    if (conn && conn !== c) conn.close();
    setupConn(c, () => {
      c.send({ type: "welcome", pass: guestPass });
      setStatus("Connecté·e ✓");
    });
  }

  function refuse(c, reason) {
    const sendAndClose = () => {
      c.send({ type: "denied", reason });
      setTimeout(() => c.close(), 1000);
    };
    if (c.open) sendAndClose();
    else c.on("open", sendAndClose);
  }

  // ---------- Joining (guest side) ----------

  async function joinRoom(code, creds) {
    ensureAudio();
    isHost = false;
    credentials = creds;
    roomCode = code;
    leaving = false;
    showRoom(true);
    setStatus("Connexion…");
    await getMedia();
    try {
      peer = await newPeer();
    } catch (err) {
      return setStatus("Erreur : " + err.type);
    }
    listenForCalls();
    connectToHost();
  }

  function connectToHost() {
    if (leaving || !peer || (conn && conn.open)) return;
    const c = peer.connect(PREFIX + roomCode, { reliable: true, metadata: credentials });
    setupConn(c, () => setStatus("En attente de validation par l'hôte…"));
  }

  function onWelcome(msg) {
    credentials = { pass: msg.pass };
    saveSession({ role: "guest", code: roomCode, pass: msg.pass });
    setStatus("Connecté·e ✓");
    send({ type: "hello", media: !!localStream });
    if (localStream) setupCall(peer.call(PREFIX + roomCode, localStream));
  }

  function setupConn(c, onOpen) {
    conn = c;
    if (c.open) onOpen();
    else c.on("open", onOpen);
    c.on("data", onData);
    c.on("close", () => {
      if (conn !== c || leaving) return;
      conn = null;
      remoteV.srcObject = null;
      if (isHost) {
        setStatus("En attente de l'autre personne…");
      } else {
        setStatus("Déconnecté·e, reconnexion…");
        setTimeout(connectToHost, 3000);
      }
    });
  }

  function setupCall(c) {
    if (call && call !== c) call.close();
    call = c;
    c.on("stream", (stream) => {
      remoteV.srcObject = stream;
      attachVoice(stream);
    });
  }

  function send(msg) {
    if (conn && conn.open) conn.send(msg);
  }

  function leave() {
    leaving = true;
    saveSession(null);
    clearInterval(heartbeat);
    if (call) call.close();
    if (conn) conn.close();
    if (peer) peer.destroy();
    if (localStream) localStream.getTracks().forEach((t) => t.stop());
    peer = conn = call = localStream = pendingGuest = null;
    invites = new Set();
    guestPass = credentials = null;
    $(".request").hidden = true;
    $(".info").textContent = "Crée une salle, puis envoie le lien d'invitation à la personne de ton choix.";
    remoteV.srcObject = selfV.srcObject = null;
    detachVoice();
    roomCode = null;
    showNotice(null);
    showRoom(false);
    setStatus("Pas connecté·e");
  }

  // ---------- Voices over the film ----------
  // The other person's voice goes through Web Audio, so it can be boosted above 100%
  // and listened to: while they speak, the film is turned down, then back up.

  const DUCK_RATIO = 0.25; // film volume while the other person speaks, relative to normal
  const DUCK_HOLD = 1500; // keep the film down this long after they stop talking
  let audioCtx = null;
  let voiceGain = null;
  let analyser = null;
  let voiceSource = null;
  let filmTween = null;
  const ducking = { active: false, normal: null, lastVoice: 0, noise: 0.01 };

  function ensureAudio() {
    if (!audioCtx) {
      audioCtx = new AudioContext();
      voiceGain = audioCtx.createGain();
      voiceGain.gain.value = Number($(".vol").value);
      voiceGain.connect(audioCtx.destination);
      analyser = audioCtx.createAnalyser();
      analyser.fftSize = 1024;
      audioCtx.onstatechange = routeVoice;
    }
    if (audioCtx.state === "suspended") audioCtx.resume().catch(() => {});
  }

  // Browsers only let audio start after a click: resume on the first click anywhere on the page.
  document.addEventListener(
    "pointerdown",
    () => {
      if (audioCtx && audioCtx.state === "suspended") audioCtx.resume().catch(() => {});
    },
    true
  );

  function attachVoice(stream) {
    ensureAudio();
    detachVoice();
    if (stream.getAudioTracks().length) {
      voiceSource = audioCtx.createMediaStreamSource(stream);
      voiceSource.connect(voiceGain);
      voiceSource.connect(analyser);
    }
    routeVoice();
  }

  function detachVoice() {
    if (voiceSource) voiceSource.disconnect();
    voiceSource = null;
    if (ducking.active) setDucked(false);
    routeVoice();
  }

  // Until Web Audio is allowed to run, the voice plays through the <video> element (no boost).
  function routeVoice() {
    const viaWebAudio = !!(audioCtx && audioCtx.state === "running" && voiceSource);
    remoteV.muted = viaWebAudio;
    remoteV.volume = Math.min(1, Number($(".vol").value));
  }

  const samples = new Float32Array(1024);
  setInterval(() => {
    if (!voiceSource || audioCtx.state !== "running") return;
    analyser.getFloatTimeDomainData(samples);
    let sum = 0;
    for (const x of samples) sum += x * x;
    const rms = Math.sqrt(sum / samples.length);
    // Follow the background noise slowly, so only real speech counts as talking.
    ducking.noise = rms < ducking.noise ? rms : ducking.noise * 0.995 + rms * 0.005;
    if (rms > Math.max(0.015, ducking.noise * 3)) ducking.lastVoice = Date.now();
    const talking = $(".duck").checked && Date.now() - ducking.lastVoice < DUCK_HOLD;
    if (talking !== ducking.active) setDucked(talking);
  }, 60);

  function setDucked(on) {
    const v = getVideo();
    if (!v) return;
    // Remember the film volume chosen by the viewer, unless we are still fading it back up.
    if (on && !filmTween) ducking.normal = v.volume;
    ducking.active = on;
    if (ducking.normal === null) return;
    fadeFilm(on ? ducking.normal * DUCK_RATIO : ducking.normal, on ? 250 : 900);
  }

  function fadeFilm(target, ms) {
    clearInterval(filmTween);
    const v = getVideo();
    if (!v) return;
    const start = v.volume;
    const t0 = Date.now();
    filmTween = setInterval(() => {
      const k = Math.min(1, (Date.now() - t0) / ms);
      window.postMessage({ __duo: "cmd", cmd: "volume", v: start + (target - start) * k }, "*");
      if (k === 1) {
        clearInterval(filmTween);
        filmTween = null;
      }
    }, 40);
  }

  // ---------- Playback sync ----------

  function currentState() {
    const v = getVideo();
    return v ? { t: v.currentTime, paused: v.paused, watch: watchId() } : { watch: watchId() };
  }

  function sendState() {
    send({ type: "state", ...currentState() });
  }

  function onData(msg) {
    if (!msg || typeof msg !== "object") return;
    if (!isHost && msg.type === "welcome") return onWelcome(msg);
    if (!isHost && msg.type === "denied") {
      leave();
      setStatus("Accès refusé");
      $(".info").textContent = msg.reason;
      return;
    }
    if (msg.type === "hello") {
      // A guest without a camera cannot call us, so we call them to still send our video.
      if (isHost && !msg.media && localStream) setupCall(peer.call(conn.peer, localStream));
      if (isHost) sendState();
      return;
    }
    if (msg.type === "state") {
      if (msg.watch && msg.watch !== watchId()) return showNotice(msg.watch);
      // Periodic check from the host: only correct real drift, and never right after a local action.
      if (isHost || Date.now() - lastLocalAction < 4000) return;
      applyRemote(msg.paused ? "pause" : "play", msg, 2.5);
      return;
    }
    if (msg.type === "play" || msg.type === "pause") applyRemote(msg.type, msg, 1);
  }

  function applyRemote(action, msg, tolerance) {
    if (msg.watch && msg.watch !== watchId()) return showNotice(msg.watch);
    showNotice(null);
    const v = getVideo();
    if (!v || typeof msg.t !== "number") return;
    const needSeek = Math.abs(v.currentTime - msg.t) > tolerance;
    const needToggle = (action === "pause") !== v.paused;
    if (!needSeek && !needToggle) return;
    ignoreLocalUntil = Date.now() + 1500;
    window.postMessage({ __duo: "cmd", cmd: action, t: needSeek ? msg.t : undefined }, "*");
  }

  function onLocalMediaEvent(e) {
    if (!(e.target instanceof HTMLVideoElement) || e.target === remoteV || e.target === selfV) return;
    if (Date.now() < ignoreLocalUntil || !conn || !conn.open) return;
    const v = e.target;
    lastLocalAction = Date.now();
    const action = e.type === "seeked" ? (v.paused ? "pause" : "play") : e.type;
    send({ type: action, t: v.currentTime, watch: watchId() });
  }

  // Media events don't bubble, so listen in the capture phase (also catches new episodes' <video>).
  for (const type of ["play", "pause", "seeked"]) {
    document.addEventListener(type, onLocalMediaEvent, true);
  }

  // Netflix navigates without reloading: tell the other side when we change title/episode.
  let lastWatch = watchId();
  setInterval(() => {
    const w = watchId();
    if (w !== lastWatch) {
      lastWatch = w;
      if (pendingWatch === w) showNotice(null);
      sendState();
    }
  }, 1000);

  // ---------- Invite link, or resume after a page reload ----------

  let invite = null;
  try {
    invite = JSON.parse(sessionStorage.getItem(INVITE_KEY));
    sessionStorage.removeItem(INVITE_KEY);
  } catch (e) {}

  const saved = loadSession();
  // After a reload the invite is still in the address, but its token is spent: reuse our pass instead.
  if (invite && !(saved && saved.code === invite.code)) {
    joinRoom(invite.code, { token: invite.token });
  } else if (saved) {
    if (saved.role === "host") createRoom(saved.code, saved);
    else joinRoom(saved.code, { pass: saved.pass });
  }
})();
