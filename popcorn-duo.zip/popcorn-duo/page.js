// Runs inside Netflix's own page context so it can drive the Netflix player.
// (Setting video.currentTime directly makes Netflix crash, so seeks go through its API.)
(() => {
  function getPlayer() {
    try {
      const api = window.netflix.appContext.state.playerApp.getAPI().videoPlayer;
      const ids = api.getAllPlayerSessionIds();
      const id = ids.find((s) => s.startsWith("watch")) || ids[0];
      return id ? api.getVideoPlayerBySessionId(id) : null;
    } catch (e) {
      return null;
    }
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window || !event.data || event.data.__duo !== "cmd") return;
    const p = getPlayer();
    const { cmd, t, v } = event.data;
    if (cmd === "volume" && typeof v === "number") {
      const volume = Math.max(0, Math.min(1, v));
      if (p && typeof p.setVolume === "function") p.setVolume(volume);
      else if (document.querySelector("video")) document.querySelector("video").volume = volume;
      return;
    }
    if (!p) return;
    if (typeof t === "number") p.seek(Math.round(t * 1000));
    if (cmd === "play") p.play();
    if (cmd === "pause") p.pause();
  });
})();
