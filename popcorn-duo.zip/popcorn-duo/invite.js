// Runs as soon as a Netflix page starts loading, before Netflix rewrites the URL:
// keeps the room and one-time token from an invite link (…#popcornduo=ROOM.TOKEN) for content.js.
// They live after "#", so they are never sent to Netflix's servers.
(() => {
  const match = location.hash.match(/popcornduo=([A-Za-z0-9]{6})\.([a-z0-9]{8,})/);
  if (!match) return;
  try {
    sessionStorage.setItem("popcornduo:invite", JSON.stringify({ code: match[1].toUpperCase(), token: match[2] }));
  } catch (e) {}
})();
